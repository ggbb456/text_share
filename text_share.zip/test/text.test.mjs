import test from 'node:test';
import assert from 'node:assert/strict';
import {TextStore} from '../server.mjs';

test('default codes are four uppercase letters and digits',()=>{
  let index=0;const store=new TextStore({random:limit=>{assert.equal(limit,36);return index++%limit;}});
  const codes=Array.from({length:9},()=>store.code());
  assert.equal(codes.join(''),'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
  assert.ok(codes.every(code=>/^[A-Z0-9]{4}$/.test(code)));
});

test('taking text consumes it once and immediately releases its code',()=>{
  const store=new TextStore();const code='自定义码-01';
  store.put(code,'第一行\n第二行');
  assert.throws(()=>store.put(code,'不能覆盖'),error=>error.status===409);
  assert.equal(store.take(code),'第一行\n第二行');
  assert.throws(()=>store.take(code),error=>error.status===404);
  assert.equal(store.bytes,0);
  store.put(code,'再次使用');assert.equal(store.take(code),'再次使用');
});

test('expiry frees codes and collisions fall back without extending length',()=>{
  let now=0;const store=new TextStore({ttl:10,now:()=>now,random:()=>0});
  store.put('AAAA','旧内容');assert.equal(store.code(),'AAAB');
  now=11;assert.equal(store.code(),'AAAA');assert.equal(store.bytes,0);
});
