import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {randomInt} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import path from 'node:path';

const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
export class TextStore {
  constructor({ttl=86400000,maxMessages=10000,maxBytes=32*1024*1024,now=Date.now,random=randomInt}={}){Object.assign(this,{ttl,maxMessages,maxBytes,now,random});this.messages=new Map();this.bytes=0;}
  sweep(){for(const [code,item]of this.messages)if(item.expires<=this.now()){this.messages.delete(code);this.bytes-=item.bytes;}}
  code(){
    this.sweep();let length=4;
    const radix=BigInt(alphabet.length);
    while(BigInt([...this.messages.keys()].filter(code=>code.length===length&&/^[A-Z0-9]+$/.test(code)).length)>=radix**BigInt(length))length++;
    for(let attempt=0;attempt<32;attempt++){const code=Array.from({length},()=>alphabet[this.random(alphabet.length)]).join('');if(!this.messages.has(code))return code;}
    for(let index=0n;;index++){let value=index,code='';for(let i=0;i<length;i++){code=alphabet[Number(value%radix)]+code;value/=radix;}if(!this.messages.has(code))return code;}
  }
  put(code,text){
    this.sweep();if(this.messages.has(code))throw new AppError(409,'取件码已被占用，请直接修改后重试');
    const bytes=Buffer.byteLength(text);
    if(this.messages.size>=this.maxMessages||this.bytes+bytes>this.maxBytes)throw new AppError(503,'临时空间已满，请稍后再试');
    this.messages.set(code,{text,bytes,expires:this.now()+this.ttl});this.bytes+=bytes;
  }
  take(code){this.sweep();const item=this.messages.get(code);if(!item)throw new AppError(404,'取件码不存在、已过期或已被取走');this.messages.delete(code);this.bytes-=item.bytes;return item.text;}
}
class AppError extends Error{constructor(status,message){super(message);this.status=status;}}
function send(res,status,data){const body=Buffer.from(JSON.stringify(data));res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':body.length});res.end(body);}
async function body(req){if(!/^application\/json(?:;|$)/i.test(req.headers['content-type']||''))throw new AppError(415,'请使用 JSON 请求');let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>600*1024)throw new AppError(413,'文字过长，最多 256 KiB');chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw new AppError(400,'请求格式不正确');}}
function codeValue(value){if(typeof value!=='string')throw new AppError(400,'请输入取件码');const code=value.trim().normalize('NFC');if(!/^[\p{L}\p{N}_-]{1,64}$/u.test(code))throw new AppError(400,'取件码可用 1–64 位文字、字母、数字、短横线或下划线');return code;}
export async function createApp({host=process.env.HOST||'0.0.0.0',port=Number(process.env.PORT||process.env.SERVER_PORT||18081),ttl=Number(process.env.TEXT_TTL_HOURS||24)*3600000,listen=true}={}){
  if(!Number.isFinite(ttl)||ttl<=0)throw Error('TEXT_TTL_HOURS 必须大于 0');
  const store=new TextStore({ttl}),assets=new Map(await Promise.all(['index.html','app.css','app.js'].map(async name=>[name,await readFile(new URL('./public/'+name,import.meta.url))]))),rates=new Map();
  const server=http.createServer({headersTimeout:15000,requestTimeout:30000,maxHeaderSize:16384},async(req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    try{
      if(req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)throw new AppError(403,'请求来源无效');
      const url=new URL(req.url,'http://localhost');
      if(req.method==='GET'&&url.pathname==='/healthz'){send(res,200,{ok:true});return;}
      const name=url.pathname==='/'?'index.html':url.pathname.slice(1);
      if(req.method==='GET'&&assets.has(name)){res.setHeader('Content-Type',{'html':'text/html; charset=utf-8','css':'text/css; charset=utf-8','js':'text/javascript; charset=utf-8'}[name.split('.').at(-1)]);res.end(assets.get(name));return;}
      const key=req.socket.remoteAddress,now=Date.now();let rate=rates.get(key);if(!rate||now-rate.at>60000){rate={at:now,count:0};rates.set(key,rate);}if(++rate.count>120)throw new AppError(429,'操作过于频繁，请稍后再试');
      if(req.method==='GET'&&url.pathname==='/api/code'){send(res,200,{code:store.code(),expiresInHours:ttl/3600000});return;}
      if(req.method==='POST'&&url.pathname==='/api/send'){const data=await body(req),code=codeValue(data.code);if(typeof data.text!=='string'||!data.text.trim())throw new AppError(400,'请先输入文字');if(Buffer.byteLength(data.text)>256*1024)throw new AppError(413,'文字过长，最多 256 KiB');store.put(code,data.text);send(res,201,{code});return;}
      if(req.method==='POST'&&url.pathname==='/api/receive'){const data=await body(req);send(res,200,{text:store.take(codeValue(data.code))});return;}
      throw new AppError(404,'页面不存在');
    }catch(error){if(!res.destroyed)send(res,error.status||500,{error:error.status?error.message:'暂时无法处理，请稍后再试'});}
  });
  server.maxConnections=128;
  const timer=setInterval(()=>{store.sweep();for(const [key,rate]of rates)if(Date.now()-rate.at>60000)rates.delete(key);},60000);timer.unref();
  if(listen)await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);});
  return {server,store,port:server.address()?.port,async close(){clearInterval(timer);if(server.listening){server.closeIdleConnections();await new Promise(resolve=>server.close(resolve));}store.messages.clear();store.bytes=0;}};
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){createApp().then(app=>{console.log(`文字站：http://${process.env.HOST||'0.0.0.0'}:${app.port}`);for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>app.close().then(()=>process.exit()));}).catch(error=>{console.error(error.message);process.exitCode=1;});}
