const base=new URL('.',import.meta.url);
const scoped=url=>new URL(url.replace(/^\//,''),base).href;
const $=id=>document.getElementById(id);let lastCode='',codeRequest=0;
function status(text=''){$('status').textContent=text;}
async function api(url,data){const response=await fetch(scoped(url),data?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}:{});const result=await response.json();if(!response.ok)throw Error(result.error);return result;}
async function generate(){const request=++codeRequest;try{const result=await api('/api/code');if(request!==codeRequest)return;$('send-code').value=result.code;$('note').textContent=`取出即销毁 · 未领取保留 ${result.expiresInHours} 小时`;}catch(error){status(error.message);}}
async function work(button,fn){button.disabled=true;status();try{await fn();}catch(error){status(error.message);}finally{button.disabled=false;}}
function switchTo(mode){const send=mode==='send';$('send-panel').hidden=!send;$('receive-panel').hidden=send;$('send-tab').setAttribute('aria-selected',send);$('receive-tab').setAttribute('aria-selected',!send);status();}
$('send-tab').onclick=()=>switchTo('send');$('receive-tab').onclick=()=>switchTo('receive');
$('send-code').oninput=()=>{codeRequest++;};$('new-code').onclick=()=>generate();
$('send-form').onsubmit=event=>{event.preventDefault();work(event.submitter,async()=>{const result=await api('/api/send',{code:$('send-code').value,text:$('text').value});lastCode=result.code;$('sent-code').textContent=result.code;$('text').value='';$('send-form').hidden=true;$('sent').hidden=false;});};
$('receive-form').onsubmit=event=>{event.preventDefault();work(event.submitter,async()=>{const result=await api('/api/receive',{code:$('receive-code').value});$('received-text').value=result.text;$('receive-form').hidden=true;$('received').hidden=false;status('文字已取出，取件码已释放');});};
async function copy(value,input){try{await navigator.clipboard.writeText(value);status('已复制');}catch{if(input){input.focus();input.select();}status('请选中文字手动复制');}}
$('copy-code').onclick=()=>copy(lastCode);$('copy-text').onclick=()=>copy($('received-text').value,$('received-text'));
$('send-again').onclick=()=>{$('sent').hidden=true;$('send-form').hidden=false;status();generate();};
$('receive-again').onclick=()=>{$('received').hidden=true;$('receive-form').hidden=false;$('received-text').value='';$('receive-code').value='';status();$('receive-code').focus();};
generate();
